import React from "react";
import UnderConstruction from "../Sections/UnderConstruction/UnderConstruction";

const About = () => {
  return (
    <UnderConstruction />
  );
};
export default About;
